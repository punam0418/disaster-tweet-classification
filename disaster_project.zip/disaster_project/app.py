from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

# Load model
model = pickle.load(open("disaster_model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    
    tweet = request.form["tweet"]
    
    vec = vectorizer.transform([tweet])
    
    prediction = model.predict(vec)
    
    if prediction[0] == 1:
        result = "⚠️ Disaster Tweet"
    else:
        result = "✅ Not a Disaster Tweet"

    return render_template("index.html", prediction_text=result)

if __name__ == "__main__":
    app.run(debug=True)